/**
 * 
 */
package vn.com.courseman.software;

import domainapp.basics.model.config.Configuration.Language;
import domainapp.basics.model.config.dodm.OsmConfig.ConnectionType;
import domainapp.core.dodm.dom.DOM;
import domainapp.core.dodm.dsm.DSM;
import domainapp.core.dodm.osm.postgresql.PostgreSQLOSM;
import domainapp.model.meta.app.DSDesc;
import domainapp.model.meta.app.OrgDesc;
import domainapp.model.meta.app.SecurityDesc;
import domainapp.model.meta.app.SysSetUpDesc;
import domainapp.model.meta.app.SystemDesc;
import domainapp.setup.SetUpConfig;

/**
 * @overview 
 *  The system class of the CourseMan application.
 * @author dmle
 * @version 3.3 
 */
@SystemDesc(
    appName="CourseMan",
    splashScreenLogo="coursemanapplogo.jpg",
    language=Language.English,
    orgDesc=@OrgDesc(
        name="Faculty of IT",
        address="K1m9 Đường Nguyễn Trãi, Quận Thanh Xuân", 
        logo="hanu.gif", 
        url="http://fit.hanu.edu.vn"
    ), 
    dsDesc=@DSDesc(
        type="postgresql", 
        dsUrl="//localhost:5432/coursemankse2016", 
        user="admin",
        password="password",
        dsmType=DSM.class,
        domType=DOM.class,
        osmType=PostgreSQLOSM.class,
        connType=ConnectionType.Client
    ), 
    // empty: to be specified from command line
    modules={}, 
    sysModules={}, 
    setUpDesc=@SysSetUpDesc(
      setUpConfigType=SetUpConfig.class
    ),
    securityDesc=@SecurityDesc(
      isEnabled=false
    )
)
public class SystemClass {
  // empty
}
