package vn.com.courseman.bspacegen.input;

import domainapp.basics.model.meta.DAssoc;
import domainapp.basics.model.meta.DAssoc.AssocEndType;
import domainapp.basics.model.meta.DAssoc.AssocType;
import domainapp.basics.model.meta.DAssoc.Associate;
import domainapp.basics.model.meta.DAttr;
import domainapp.basics.model.meta.DAttr.Type;
import domainapp.basics.model.meta.DClass;

/**
 * Represents an enrolment
 * 
 * @author dmle
 * 
 */
@DClass(schema="courseman")
public class Enrolment {
  /*** STATE SPACE **/
  // attributes
  @DAttr(name="id",type=Type.Integer,id=true,auto=true,optional=false,mutable=false,min=1)
  private int id;

  @DAttr(name="student",type=Type.Domain,optional=false)
  @DAssoc(ascName="std-has-enrols",role="enrolment",
    ascType=AssocType.One2Many,endType=AssocEndType.Many,
    associate=@Associate(type=Student.class,cardMin=1,cardMax=1),
    dependsOn=true)
  private Student student;
  
  @DAttr(name="module",type=Type.Domain,optional=false)
  @DAssoc(ascName="mod-has-enrols",role="enrolment",
      ascType=AssocType.One2Many,endType=AssocEndType.Many,
    associate=@Associate(type=CourseModule.class,cardMin=1,cardMax=1),
    dependsOn=true)
  private CourseModule module;
  
  @DAttr(name="internalMark",type=Type.Double,optional=true,min=0.0,max=10.0)
  private Double internalMark;
  
  @DAttr(name="examMark",type=Type.Double,optional=true,min=0.0,max=10.0)
  private Double examMark;

  // v2.6.4.b derived from two attributes
  @DAttr(name="finalMark",type=Type.Integer,auto=true,mutable=false,optional=true,
      serialisable=false,
      derivedFrom={"internalMark", "examMark"})
  private Integer finalMark;

  @DAttr(name="finalGrade",type=Type.Char,auto=true,mutable=false,optional=true
      /* Note: no need to do this:
       derivedFrom={"internalMark,examMark"}
       * because finalGrade and finalMark are updated by the same method and this is already specified by finalMark (below)
       */
  )
  private Character finalGrade;

  /*** BEHAVIOUR SPACE **/
}
