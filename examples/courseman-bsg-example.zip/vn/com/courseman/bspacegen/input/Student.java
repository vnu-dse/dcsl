package vn.com.courseman.bspacegen.input;

import java.util.Collection;

import domainapp.basics.model.meta.DAssoc;
import domainapp.basics.model.meta.DAssoc.AssocEndType;
import domainapp.basics.model.meta.DAssoc.AssocType;
import domainapp.basics.model.meta.DAssoc.Associate;
import domainapp.basics.model.meta.DAttr;
import domainapp.basics.model.meta.DAttr.Type;
import domainapp.basics.model.meta.DClass;
import domainapp.basics.model.meta.Select;

/**
 * Represents a student.
 * 
 * @author dmle
 * @version 2.0
 */
@DClass(schema="courseman")
public class Student{
  /*** STATE SPACE **/
  @DAttr(name="id",type=Type.Integer,id=true,auto=true,mutable=false,optional=false,min=1.0)
  private int id;
  
  @DAttr(name="name",type=Type.String,length=30,optional=false)
  private String name;
  
  @DAttr(name = "address", type = Type.Domain, length = 20, optional = true)
  @DAssoc(ascName="student-has-address",role="student",
    ascType=AssocType.One2One, endType=AssocEndType.One,
    associate=@Associate(type=Address.class,cardMin=1,cardMax=1))
  private Address address;

  @DAttr(name="enrolments",type=Type.Collection,optional=false,serialisable=false,
		  filter=@Select(clazz=Enrolment.class))
  @DAssoc(ascName="std-has-enrols",role="student",
    ascType=AssocType.One2Many,endType=AssocEndType.One,
    associate=@Associate(type=Enrolment.class,cardMin=0,cardMax=30))
  private Collection<Enrolment> enrolments;  

  /*** BEHAVIOUR SPACE **/
}
