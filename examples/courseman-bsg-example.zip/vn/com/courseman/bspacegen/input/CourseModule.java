package vn.com.courseman.bspacegen.input;

import java.util.Collection;

import domainapp.basics.model.meta.DAssoc;
import domainapp.basics.model.meta.DAssoc.AssocEndType;
import domainapp.basics.model.meta.DAssoc.AssocType;
import domainapp.basics.model.meta.DAssoc.Associate;
import domainapp.basics.model.meta.DAttr;
import domainapp.basics.model.meta.DAttr.Type;
import domainapp.basics.model.meta.DClass;
import domainapp.basics.model.meta.MetaConstants;
import domainapp.basics.model.meta.Select;

/**
 * Represents a course module.
 * @author dmle
 * @version 2.0
 */
@DClass(schema="courseman")
public class CourseModule {
  /*** STATE SPACE **/
  @DAttr(name="id",type=Type.Integer,id=true,auto=true,mutable=false,optional=false,min=1)
  private int id;
  
  @DAttr(name="code",type=Type.String,length=6,auto=true,mutable=false,optional=false,
      derivedFrom={"semester"})
  private String code;
  
  @DAttr(name="name",type=Type.String,length=30,optional=false)
  private String name;
  
  @DAttr(name="semester",type=Type.Integer,optional=false,min=1,max=10)
  private int semester;
  
  @DAttr(name="credits",type=Type.Integer,optional=false,min=1,max=5)
  private int credits;

  // v2.6.4b: added support for this association
  @DAttr(name="enrolments",type=Type.Collection,optional=false,serialisable=false,
		  filter=@Select(clazz=Enrolment.class))
  @DAssoc(ascName="mod-has-enrols",role="module",
      ascType=AssocType.One2Many,endType=AssocEndType.One,
      associate=@Associate(type=Enrolment.class,cardMin=0,cardMax=MetaConstants.CARD_MORE))
  private Collection<Enrolment> enrolments;
  
  /*** BEHAVIOUR SPACE **/
}
